Trained_models are available at https://pan.baidu.com/s/1-pgSXN6-NXLzmTp21L_qIg with code: `4gat`
or google drive: https://drive.google.com/drive/folders/19_lSUPrpLDZl9AyewhHBsHidZEpTMIV5?usp=sharing

Put  models in the 'trained_models/' folder.
